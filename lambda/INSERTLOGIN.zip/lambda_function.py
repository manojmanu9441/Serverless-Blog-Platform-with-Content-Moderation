import json
import boto3
import uuid

# Initialize AWS resources
dynamodb = boto3.resource('dynamodb')
sqs = boto3.client('sqs')
sns = boto3.client('sns')

# Define table and SQS Queue URL
table = dynamodb.Table('LOGIN')
SQS_QUEUE_URL = 'https://sqs.us-east-1.amazonaws.com/491085415620/BLOG'  # Replace with your SQS URL

def lambda_handler(event, context):
    try:
        # Parse incoming request
        body = json.loads(event['body']) if 'body' in event else event

        # Extract user details
        userId = body.get('userId')
        password = body.get('password')
        email = body.get('email')

        if not userId or not password or not email:
            return {
                'statusCode': 400,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'POST, OPTIONS',
                    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                },
                'body': json.dumps({'message': 'Missing required fields!'})
            }

        # Check if user already exists
        response = table.get_item(Key={'userId': userId})
        if 'Item' in response:
            return {
                'statusCode': 409,  # Conflict: User already exists
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'POST, OPTIONS',
                    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                },
                'body': json.dumps({'message': 'User already exists!'})
            }

        # Create a unique SNS topic for the user
        sns_response = sns.create_topic(Name=f"user-{userId}-topic")
        sns_topic_arn = sns_response['TopicArn']

        # Store user details and SNS topic ARN in DynamoDB
        table.put_item(Item={'userId': userId, 'password': password, 'email': email, 'snsTopicArn': sns_topic_arn})

        # ✅ Subscribe the user to their SNS topic (for notifications)
        sns.subscribe(
            TopicArn=sns_topic_arn,
            Protocol='email',
            Endpoint=email  # User's email
        )

        # ✅ Send SNS Notification to Admin
        sns.publish(
            TopicArn='arn:aws:sns:us-east-1:491085415620:ADMIN-BLOG',  # Admin's SNS topic ARN
            Message=json.dumps({'userId': userId, 'email': email, 'message': 'New user registered!'}),
            Subject='New User Signup Notification'
        )

        # ✅ Send user details to SQS for further processing
        sqs.send_message(
            QueueUrl=SQS_QUEUE_URL,
            MessageBody=json.dumps({'userId': userId, 'email': email, 'message': 'User registered successfully!'})
        )

        return {
            'statusCode': 201,  # Created
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization',
            },
            'body': json.dumps({'success': True, 'message': 'User registered successfully!', 'userId': userId})
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization',
            },
            'body': json.dumps({'success': False, 'error': str(e)})
        }

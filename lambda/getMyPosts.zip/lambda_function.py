import json
import boto3
from boto3.dynamodb.conditions import Key

# Initialize DynamoDB
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('BLOGS')

def lambda_handler(event, context):
    print("🚀 Full event received:", json.dumps(event, indent=2))

    headers = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "OPTIONS, GET",
        "Access-Control-Allow-Headers": "Content-Type"
    }

    # Handle OPTIONS preflight request
    if event.get("httpMethod") == "OPTIONS":
        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps({"message": "CORS preflight successful"})
        }

    # Extract query parameters
    query_params = event.get('queryStringParameters', {})
    user_id = query_params.get('userId', None)

    if not user_id:
        return {
            "statusCode": 400,
            "headers": headers,
            "body": json.dumps({"error": "Missing userId"})
        }

    try:
        print(f"🔍 Fetching posts for userId: {user_id}")

        response = table.query(
            IndexName='userId-index',
            KeyConditionExpression=Key('userId').eq(user_id)
        )

        user_posts = response.get('Items', [])
        print(f"✅ Found {len(user_posts)} posts for userId: {user_id}")

        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps(user_posts)  # ✅ Convert list to JSON string
        }

    except Exception as e:
        print(f"❌ Error retrieving posts: {str(e)}")
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({"error": str(e)})
        }
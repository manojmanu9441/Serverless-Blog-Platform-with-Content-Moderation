import json
import boto3

# Initialize DynamoDB
dynamodb = boto3.resource('dynamodb')

# ✅ Ensure this is the correct table name
TABLE_NAME = "BLOGS"  # Change this if your table name is different
table = dynamodb.Table(TABLE_NAME)

def lambda_handler(event, context):
    try:
        # ✅ Scan to get all blog posts
        response = table.scan()
        blogs = response.get('Items', [])  # Get all blog items

        return {
            'statusCode': 200,
            'headers': {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"  # Enable CORS for frontend
            },
            'body': json.dumps({'success': True, 'blogs': blogs})
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            'body': json.dumps({'success': False, 'error': str(e)})
        }

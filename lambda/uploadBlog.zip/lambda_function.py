import json
import boto3
import uuid
import base64

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table("BLOGS")

def lambda_handler(event, context):
    try:
        body = json.loads(event["body"]) if "body" in event else event

        user_id = body.get("userId")  # ✅ Ensure we get userId from frontend
        title = body.get("title")
        content = body.get("content")
        image = body.get("image", None)

        if not user_id or not title or not content:
            return {
                "statusCode": 400,
                "body": json.dumps({"message": "Missing required fields: userId, title, or content"}),
                "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"}
            }

        blog_id = str(uuid.uuid4())

        image_url = None
        if image:
            try:
                s3 = boto3.client("s3")
                bucket_name = "blogdata-12"
                image_key = f"blogs/{blog_id}.jpg"
                image_binary = base64.b64decode(image)
                s3.put_object(Bucket=bucket_name, Key=image_key, Body=image_binary, ContentType="image/jpeg")
                image_url = f"https://{bucket_name}.s3.amazonaws.com/{image_key}"
            except Exception as e:
                return {
                    "statusCode": 500,
                    "body": json.dumps({"success": False, "error": f"Image upload failed: {str(e)}"}),
                    "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"}
                }

        table.put_item(Item={
            "BlogId": blog_id,
            "userId": user_id,  # ✅ Store correct userId in DynamoDB
            "title": title,
            "content": content,
            "imageUrl": image_url if image_url else None
        })

        return {
            "statusCode": 200,
            "body": json.dumps({"success": True, "blogId": blog_id}),
            "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"}
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"success": False, "error": str(e)}),
            "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"}
        }

import json
import boto3

# Initialize DynamoDB resource
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
table = dynamodb.Table('LOGIN')

def lambda_handler(event, context):
    try:
        print("Received Event:", event)  # ✅ Debugging: Check incoming request

        # Ensure body exists and parse JSON safely
        body = json.loads(event.get('body', '{}'))  # ✅ Handles missing body
        user_id = body.get('userId')
        password = body.get('password')
        print(user_id,password)
        if not user_id or not password:
            return {
                'statusCode': 400,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'success': False, 'message': 'Missing userId or password'})
            }

        # Query the database to check user credentials
        response = table.get_item(Key={'userId': user_id})
        print(response,"www")
        print("DynamoDB Response:", response)  # ✅ Debugging: Check query result

        if 'Item' not in response:
            return {
                'statusCode': 401,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'success': False, 'message': 'Invalid userId or password'})
            }

        user_data = response['Item']

        # Validate the password
        if user_data.get('password') != password:
            return {
                'statusCode': 401,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'success': False, 'message': 'Invalid userId or password'})
            }

        # ✅ Login successful
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization',
            },
            'body': json.dumps({'success': True, 'message': 'Login successful'})
        }

    except Exception as e:
        print(f"Lambda Error: {str(e)}")  # ✅ Logs error to CloudWatch
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'success': False, 'error': str(e)})
        }

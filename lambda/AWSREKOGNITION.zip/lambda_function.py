import json
import boto3
import time
import urllib.parse

# Initialize AWS clients
rekognition_client = boto3.client('rekognition', region_name='us-east-1')
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
sns_client = boto3.client('sns', region_name='us-east-1')
s3_client = boto3.client('s3')  # Added S3 client

# Environment variables
BLOG_TABLE_NAME = 'BLOGS'
MODERATION_LOG_TABLE_NAME = 'Moderation'
LOGIN_TABLE_NAME = 'LOGIN'
S3_BASE_URL = 'https://blogdata-12.s3.amazonaws.com/'

def lambda_handler(event, context):
    print("Received event:", json.dumps(event))
    
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        encoded_key = record['s3']['object']['key']
        key = urllib.parse.unquote_plus(encoded_key)
        print(f"Processing image: {key} from bucket: {bucket}")
        
        # Construct full S3 URL
        full_s3_url = S3_BASE_URL + key

        # Detect inappropriate content using Rekognition
        try:
            response = rekognition_client.detect_moderation_labels(
                Image={'S3Object': {'Bucket': bucket, 'Name': key}},
                MinConfidence=80
            )
            labels = response.get('ModerationLabels', [])
            moderation_labels = [label['Name'] for label in labels]
        except Exception as e:
            print(f"Error calling Rekognition: {e}")
            continue

        # Get blog details based on imageUrl
        blog_table = dynamodb.Table(BLOG_TABLE_NAME)
        moderation_table = dynamodb.Table(MODERATION_LOG_TABLE_NAME)
        login_table = dynamodb.Table(LOGIN_TABLE_NAME)
        
        try:
            blog_response = blog_table.scan(
                FilterExpression="contains(imageUrl, :imgUrl)",
                ExpressionAttributeValues={":imgUrl": key}
            )
            
            if blog_response.get('Items'):
                blog_item = blog_response['Items'][0]
                blog_id = blog_item['BlogId']
                user_id = blog_item['userId']
                title = blog_item['title']
                content = blog_item['content']
                image_url = blog_item['imageUrl']
            else:
                print(f"No blog entry found for image: {key}")
                continue
        except Exception as e:
            print(f"Error fetching blog details: {e}")
            continue

        # Retrieve user's email and SNS topic ARN from LOGIN_TABLE
        try:
            user_response = login_table.get_item(Key={'userId': user_id})
            user_email = user_response.get('Item', {}).get('email')
            user_sns_topic_arn = user_response.get('Item', {}).get('snsTopicArn')
        except Exception as e:
            print(f"Error fetching user details: {e}")
            user_email = None
            user_sns_topic_arn = None

        # If user doesn't have a SNS topic ARN, create one
        if not user_sns_topic_arn:
            try:
                sns_response = sns_client.create_topic(Name=f"user-{user_id}-topic")
                user_sns_topic_arn = sns_response['TopicArn']
                
                # Update the user's SNS topic ARN in the LOGIN_TABLE
                login_table.update_item(
                    Key={'userId': user_id},
                    UpdateExpression="SET snsTopicArn = :snsTopicArn",
                    ExpressionAttributeValues={':snsTopicArn': user_sns_topic_arn}
                )
                print(f"Created new SNS topic for user {user_id}: {user_sns_topic_arn}")
            except Exception as e:
                print(f"Error creating SNS topic for user: {e}")
                user_sns_topic_arn = None

        # Store moderation results
        moderation_entry = {
            'BlogId': blog_id,
            'UserId': user_id,
            'Title': title,
            'Content': content,
            'ImageUrl': image_url,
            'ModerationLabels': moderation_labels,
            'Timestamp': int(time.time())
        }

        try:
            moderation_table.put_item(Item=moderation_entry)
            print(f"Stored moderation log for BlogId {blog_id}.")
        except Exception as e:
            print(f"Error writing to MODERATION_LOG_TABLE: {e}")

        # If inappropriate content is detected
        if moderation_labels:
            message = f"\U0001F6A8 Alert: Inappropriate content detected in blog '{title}' ({blog_id}): {moderation_labels}"
            
            # Delete the image from S3
            try:
                s3_client.delete_object(Bucket=bucket, Key=key)
                print(f"Deleted image from S3: {key}")
            except Exception as e:
                print(f"Error deleting image from S3: {e}")

            # Delete the blog entry from BLOG_TABLE
            try:
                blog_table.delete_item(Key={'BlogId': blog_id})
                print(f"Deleted blog entry {blog_id} due to policy violation.")
            except Exception as e:
                print(f"Error deleting blog entry: {e}")

            # Notify admin via SNS
            try:
                sns_client.publish(
                    TopicArn=SNS_TOPIC_ARN,
                    Message=message,
                    Subject="Blog Moderation Alert"
                )
                print("SNS notification sent to admin.")
            except Exception as e:
                print(f"Error publishing to SNS: {e}")

            # Notify user via their unique SNS topic
            if user_sns_topic_arn and user_email:
                try:
                    sns_client.publish(
                        TopicArn=user_sns_topic_arn,
                        Message=f"Dear {user_id},\n\nYour blog post '{title}' was removed due to inappropriate content: {moderation_labels}.",
                        Subject="Blog Post Removed - Policy Violation"
                    )
                    print(f"Email sent to {user_email}.")
                except Exception as e:
                    print(f"Error sending email to user: {e}")

    return {
        'statusCode': 200,
        'body': json.dumps('Image moderation processing complete.')
    }
